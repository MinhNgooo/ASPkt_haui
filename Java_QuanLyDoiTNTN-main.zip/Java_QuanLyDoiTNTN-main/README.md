Bài tập lớn môn lập trình Java
Chủ đề: Xây dựng chương trình quản lý đội thanh niên tình nguyện
Yêu cầu: 
- Hàng năm đoàn trường tổ chức tuyển tình nguyện viên theo tiêu chí  tình nguyện đăng ký cho sv đăng ký và quản lý theo đơn vị khoa, trường
- Đoàn trường lên lịch phỏng vấn tiếp nhận sinh viên tình nguyện; phân công tiếp nhận và quản lý theo khoa; lên lịch và huy động sinh viên tình nguyện theo các sự kiện
- cấp phí hoạt động cho các đội
- tổ chức quản lý thành viên trong các phong trào tình nguyện
- báo cáo thống kê
