/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.btl_java_kyxuan;

import view.Login;

/**
 *
 * @author linhc
 */
public class BTL_JAVA_KyXuan {
    public static void main(String[] args) {
        System.setProperty("file.encoding", "UTF-8");
        Login view = new Login();
    }
}
